import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { Observable, Subscriber } from 'rxjs';
import { validfirstname} from 'src/app/modals/validation';
import { validPhonNo } from 'src/app/modals/validForNumber';
// import { validPhonNo } from 'src/app/modals/validForNumber';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent {
  constructor(private authService:AuthService ,private snackBar:MatSnackBar ,private router:Router){}

  registerForm=new FormGroup({
    "userName":new FormControl('',validfirstname()),
    'password':new FormControl('',[Validators.required,Validators.minLength(6)]),
    'email':new FormControl('',[Validators.required,Validators.email,Validators.pattern('^[a-z0-9+._-]+@[a-z]+\.[a-z]{2,3}')]),
    'contactno':new FormControl('',validPhonNo()),
    "image":new FormControl('',[Validators.required])
    // "password":new FormControl(''),
    // "email":new FormControl(''),
    // "contactno":new FormControl(''),
    // "image":new FormControl('')
    // phoneNumber: new FormControl('', [Validators.required, Validators.pattern("[789]\\d{9}")])
    // fullName : new FormControl('',[Validators.required ,Validators.pattern("^[a-zA-Z\\s]*$")]),

  })
  get userName(){
    return this.registerForm.controls['userName']
   }
   get contactno(){
    return this.registerForm.controls['contactno']
   }
   get email(){
    return this.registerForm.controls['email']
   }
   get password(){
    return this.registerForm.controls['password']
   }

  respdata:any
  register(){
     this.authService.register(this.registerForm.value).subscribe(
       (response)=>{
        console.log(response);
            // alert("User Registered");
            this.snackBar.open('Registeration Successfully','OK',{
              duration:1500,
              horizontalPosition: 'center',
              verticalPosition: 'top',
              panelClass: ['mat-toolbar','mat-primary']
            });
            this.router.navigate(["/login"])
          }
        )
      }

      myImage!:Observable<any>;
  base64code!:any;
  changeImage(e:any){
    this.image!.setValue(e.target.value, {
      onlySelf: true
     })
  }
  get image(){
    return this.registerForm.get('image');
   }
   onChange($event:Event,e:any) {
    const target=$event.target as HTMLInputElement;
    const file:File=(target.files as FileList)[0];
    console.log(file);
    this.convertToBase64(file);
       }
       convertToBase64(file :File){//arraangement to receive something
        const observable=new Observable ((subscriber:Subscriber<any>)=>{
          this.readFile(file,subscriber);
        })
        observable.subscribe((d)=>{
          //setting value of image here
          this.image!.setValue(d);
           console.log ("key "+ d);
          }
       )
    }
readFile(file:File,subscriber:Subscriber<any>){
const filereader=new FileReader();
filereader.readAsDataURL(file);
filereader.onload=() =>{
  subscriber.next(filereader.result);
  subscriber.complete();
}
filereader.onerror=() =>{
  subscriber.error();
  subscriber.complete();
}
}
}


