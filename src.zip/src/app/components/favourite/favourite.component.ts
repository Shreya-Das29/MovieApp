import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { Movie } from 'src/app/modals/movie';
import { AuthService } from 'src/app/services/auth.service';
import { MovieService } from 'src/app/services/movie.service';

@Component({
  selector: 'app-favourite',
  templateUrl: './favourite.component.html',
  styleUrls: ['./favourite.component.css']
})
export class FavouriteComponent {

  constructor(private authService:AuthService, private movieService:MovieService, private route:Router) {
    this.display();
  }

  userName:string=this.movieService.userName;
  movieName:string="";

  movie!:Movie[];
    display(){
      console.log("inside display method : ");
      this.movieService.displayCartDetails().subscribe(data=>{
        this.movie = data;  
      })
    }
    RemoveFromFavourite(data:Movie){
      if(data!== null || data!=='') {
        this.movieService.removeFromFavourite(data).subscribe((response:any)=>{
        console.log("movie Deleted");
        console.log(data);
        this.display();
      })
    }
    }
    logOut(){
      this.authService.logOut();
      this.route.navigate(['/home']);
    }
    searchMovie(){
      console.log("searchbar value: "+this.movieName);
      this.movieService.movieName=this.movieName;
   }
}
