import { Component } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { Movie } from 'src/app/modals/movie';
import { AuthService } from 'src/app/services/auth.service';
import { MovieService } from 'src/app/services/movie.service';

@Component({
  selector: 'app-genres',
  templateUrl: './genres.component.html',
  styleUrls: ['./genres.component.css']
})
export class GenresComponent {

  constructor(private authService:AuthService, private movieService:MovieService, private route:Router, private snack:MatSnackBar) {
    this.display();
  }

  movieName:string="";
  movie!:Movie[];

  logOut(){
    this.authService.logOut();
    this.route.navigate(['/home']);
  }

  searchMovie(){
    console.log("searchbar value: "+this.movieName);
    this.movieService.movieName=this.movieName;
 }

 display(){
  console.log("inside display method : ");
   this.movie = this.movieService.res.items.filter(p=>p.genres.includes(this.movieService.genre)).map(m=>m);
   console.log("Search Results: "+this.movie);
  }

  addToFavourite(data:Movie){
    this.movieService.addToFavourite(data).subscribe((response:any)=>{
      console.log("movie Added");
      this.snack.open('Movie Added to Favourite', 'OK', {
        duration: 3000,
        horizontalPosition: 'center',
        verticalPosition: 'top',
        panelClass: ['mat-toolbar', 'mat-primary']
      });
    // console.log(data);
  },err=>{
    this.snack.open('Movie already added','OK',{
      duration:1500
    });
  });
  }
}
