import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  constructor(private authService:AuthService, private route:Router ,private snackBar:MatSnackBar) {}

  ngOnInit(): void {
    this.initForm();
  }
  static uName:string;
  loginForm!: FormGroup;
  // loginForm=new FormGroup({
  //   "userName":new FormControl(''),
  //   "password":new FormControl('')
  // });
  initForm() {
    this.loginForm = new FormGroup({
      'userName':new FormControl('',[Validators.required]),
      'password':new FormControl('',[Validators.required,Validators.minLength(6)])
    });
  }
  login(){
    // LoginComponent.uName=this.loginForm.value.userName;
    console.log("ng model username: "+this.loginForm.value.userName);
    LoginComponent.uName=this.loginForm.value.userName;
    this.authService.login(this.loginForm.value).subscribe(result=>{
      console.log("inside login process method "+result);
      this.authService.setToken(result);
      // alert("Login Success")
      this.snackBar.open('Login Successfully','OK',{
        duration:1500,
        horizontalPosition: 'center',
        verticalPosition: 'top',
        panelClass: ['mat-toolbar','mat-primary']
      });
      this.route.navigate(["/dash"])
    }, error =>{
      // alert("Invalid Credentials");
      this.snackBar.open('Invalid Credentials','OK',{
        duration:1500,
        horizontalPosition: 'center',
        verticalPosition: 'top',
        panelClass: ['mat-toolbar','mat-primary']
      });
      console.log(error);
  })
 }
}
