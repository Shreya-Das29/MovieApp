import { Component } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { Movie } from 'src/app/modals/movie';
import { Result } from 'src/app/modals/result';
import { AuthService } from 'src/app/services/auth.service';
import { MovieService } from 'src/app/services/movie.service';

@Component({
  selector: 'app-movie',
  templateUrl: './movie.component.html',
  styleUrls: ['./movie.component.css']
})
export class MovieComponent {

  constructor(private authService:AuthService, private movieService:MovieService, private route:Router, private snack:MatSnackBar) {}

  res!:Result;
  movieName:string="";
  movie:Movie = this.movieService.movie;

  logOut(){
    this.authService.logOut();
    this.route.navigate(['/home']);
  }

  data!:any[];
  AddToFavourite(data:any){
    if(data!== null || data!=='') {
      this.movieService.addToFavourite(data).subscribe((response:any)=>{
        console.log("movie Added");
        this.snack.open('Movie Added to Favourite', 'OK', {
          duration: 3000,
          horizontalPosition: 'center',
          verticalPosition: 'top',
          panelClass: ['mat-toolbar', 'mat-primary']
        });
      console.log(data);
    },
    err=>{
        this.snack.open('Movie already added','OK',{
          duration:1500
        })
    })
  }
 
}


searchMovie(){
  console.log("searchbar value: "+this.movieName);
  this.movieService.movieName=this.movieName;
}

}
