import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { Movie } from 'src/app/modals/movie';
import { Search } from 'src/app/modals/search';
import { AuthService } from 'src/app/services/auth.service';
import { MovieService } from 'src/app/services/movie.service';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit{

  constructor(private authService:AuthService, private movieService:MovieService, private route:Router, private snack:MatSnackBar) {}

  res:Search=new Search();
  movieList!:any;
  movieName:string="";

  ngOnInit(): void {
    this.display();
  }

  movie!:Movie[];
  display(){
    console.log("inside display method : ");
     this.movie = this.movieService.res.items.filter(p=>p.title.toLowerCase().includes( this.movieService.movieName.toLowerCase())).map(m=>m);
     console.log("Search Results: "+this.movie);
    }

    logOut(){
      this.authService.logOut();
      this.route.navigate(['/home']);
    }
  
    searchMovie(){
      console.log("searchbar value: "+this.movieName);
      this.movieService.movieName=this.movieName;
      this.display();
    }

    AddToFavourite(data:Movie){
      this.movieService.addToFavourite(data).subscribe((response:any)=>{
        console.log("movie Added");
        this.snack.open('Movie Added to Favourite', 'OK', {
          duration: 3000,
          horizontalPosition: 'center',
          verticalPosition: 'top',
          panelClass: ['mat-toolbar', 'mat-primary']
        });
      console.log(data);
    },err=>{
      this.snack.open('Movie already added','OK',{
        duration:1500
      });
    });
    }

}
