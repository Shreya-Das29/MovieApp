import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Result } from 'src/app/modals/result';
import { MovieService } from 'src/app/services/movie.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor(private movieService:MovieService, private snackBar:MatSnackBar) {}
  
  res!:Result;
  movieList!:any

  ngOnInit(): void {
    this.movieService.getMovie().subscribe(data=>{
      console.log(data);
      this.movieList=data;
      this.res=this.movieList;
    })
  }
  LoginFirst(){
    // alert("Please Register/Login First");
    this.snackBar.open('Please Register/Login First', 'OK', {
      duration: 3000,
      horizontalPosition: 'center',
      verticalPosition: 'top',
      panelClass: ['mat-toolbar', 'mat-primary']
    });
  }
}
