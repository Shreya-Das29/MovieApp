import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { Movie } from 'src/app/modals/movie';
import { Result } from 'src/app/modals/result';
import { AuthService } from 'src/app/services/auth.service';
import { MovieService } from 'src/app/services/movie.service';
import { LoginComponent } from '../login/login.component';

@Component({
  selector: 'app-dash',
  templateUrl: './dash.component.html',
  styleUrls: ['./dash.component.css']
})
export class DashComponent implements OnInit {
  showAdd:boolean = false;
  showUpdate:boolean = false;
  fav = 0;
  res:Result=new Result();
  movieList!:any;
  userName:string=this.movieService.userName;
  movieName:string="";
  name:any;
  constructor(private authService:AuthService, private movieService:MovieService, private route:Router, private snackbar:MatSnackBar) {
    this.getprofile();
  }

  ngOnInit(): void{
    console.log("ngOnInit Invoked : "+LoginComponent.uName);
    this.name=LoginComponent.uName;
    this.movieService.getMovie().subscribe(data=>{
      console.log(data);
      this.movieList=data;
      this.movieService.res = this.movieList;
      this.res=this.movieList;
    })
  }

  data!:any[];
  LoginFirstOrAddToCart(data:any){
    if(data!== null || data!=='') {
      this.fav += 1;
      this.movieService.addToFavourite(data).subscribe((response:any)=>{
        console.log("movie Added");
        this.snackbar.open('Movie Added to Favourite', 'OK', {
          duration: 3000,
          horizontalPosition: 'center',
          verticalPosition: 'top',
          panelClass: ['mat-toolbar', 'mat-primary']
        });
      // console.log(data);
    },
    err=>{
      this.snackbar.open('Movie already added','OK',{
        duration:1500
      })
    })
  }

  }

  logOut() {
    this.authService.logOut();
    this.route.navigate(['/home']);
  }

  navigateToCart(metadata:Movie){
    this.movieService.movie = metadata;
  }

  searchMovie(){
    console.log("searchbar value: "+this.movieName);
    this.movieService.movieName=this.movieName;
 }

 ActionSearch(){
  this.movieService.genre="Action";
 }
 AdvSearch(){
  this.movieService.genre="Adventure";
 }
 ComedySearch(){
  this.movieService.genre="Comedy";
 }
 DramaSearch(){
  this.movieService.genre="Drama";
 }
 ThrillerSearch(){
  this.movieService.genre="Thriller";
 }
 FictionSearch(){
  this.movieService.genre="Sci-Fi";
 }
pic:any;
profilePic:any;
 getprofile() {
  this.authService.getUserDetails(this.userName).subscribe(
    response => {
     this.pic=response;
     console.log(this.pic);
     this.profilePic=this.pic.image;
     console.log(this.profilePic);
     
    }
  )
}
}
