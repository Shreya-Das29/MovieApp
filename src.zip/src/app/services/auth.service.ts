import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { LoginComponent } from '../components/login/login.component';
import { Login } from '../modals/login';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor(private http:HttpClient, private route:Router) { }

  baseUrl:string="http://localhost:8085/api/v1"
  baseUrl1:string="http://localhost:8082/api/v3"

  register(user:any){
    return this.http.post(this.baseUrl1+"/register",user)
  }

  // login(user:any){
  //   return this.http.post(this.baseUrl+"/login",user)
  // }
  login(user: Login):Observable<Object>{
    console.log("userName: "+user.userName);
    this.getUserDetails(user.userName);
    return this.http.post(`${this.baseUrl}/login`, user);
  }
  
  setToken(token:any){
    localStorage.setItem("token",token);
    console.log("Token set successful");
    return true;
  }

  getToken(){
    return localStorage.getItem("token");
  }

  isLogedIn()
  {
    let token = localStorage.getItem("token");
    if(token==undefined || token==null || token=="") {
      return false;
    }
    else{
      return true;
    }
  }

  logOut() {
    localStorage.removeItem("token");
    this.route.navigate(['login']);
  }
  getUserDetails(userName:any):Observable<any> {
    return this.http.get(`${this.baseUrl1}/movieData/${LoginComponent.uName}`,userName);
  }
}
