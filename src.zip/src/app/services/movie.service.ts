import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { LoginComponent } from '../components/login/login.component';
import { Login } from '../modals/login';
import { Movie } from '../modals/movie';
import { Result } from '../modals/result';

@Injectable({
  providedIn: 'root'
})
export class MovieService {

  movieName!:string;
  genre!: string;

  res:Result=new Result();
  movie!:Movie;
  constructor(private http:HttpClient) { }

  baseUrl:string="http://localhost:8081/api/v2"
  baseUrl2:string="http://localhost:8082/api/v3"

  getMovie(){
    return this.http.get(this.baseUrl+"/movie")
  }
  addToFavourite(data:Movie): Observable<Object>{
    console.log("inside add to cart "+LoginComponent.uName);
    return this.http.post(`http://localhost:8082/api/v3/movie/add/${LoginComponent.uName}`,data);
    }
    userName!:string;
    password:any;
  
    getUserDetails(userName:any):Observable<any> {
      return this.http.get(`${this.baseUrl2}v3/user/${userName}`,userName);
    }
    url3:string=`http://localhost:9000/api/v3/movie/`; 
    displayCartDetails():Observable<any>{
    return this.http.get<Movie[]>(`${this.url3}`+`${LoginComponent.uName}`);
  }

  removeFromFavourite(data:Movie): Observable<Object> {
    return this.http.delete(`http://localhost:8082/api/v3/movie/delete/${LoginComponent.uName}/${data.id}`);
  }
}
