import { AbstractControl, ValidationErrors, ValidatorFn } from "@angular/forms";

export function validPhonNo():ValidatorFn{
    return (control:AbstractControl):ValidationErrors | null =>{
    const re=new RegExp("[789]\\d{9}");
    if(re.test(control.value)){
        return null;
    }
    else{
        return {validPhonNo:{value:control.value}};
    }
}
}
