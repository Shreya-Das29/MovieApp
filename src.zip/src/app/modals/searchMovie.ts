export class SearchMovie {
    description!:string;
    id!:string;
    image!:string;
    resultType!:string;
    title!:string;
}