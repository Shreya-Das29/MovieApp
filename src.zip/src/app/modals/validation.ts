import { AbstractControl, ValidationErrors, ValidatorFn } from "@angular/forms";
export function validfirstname():ValidatorFn{
    return (control:AbstractControl):ValidationErrors | null =>{
    const re=new RegExp("^[A-Z][a-z]*$");
    // const re=new RegExp("^[A-Z][A-Za-z]$");
    if(re.test(control.value)){
        return null;
    }
    else{
        return {validtefirstname:{value:control.value}};
    }
}
}

// export function validPhonNo():ValidatorFn{
//     return (control:AbstractControl):ValidationErrors | null =>{
//     const re=new RegExp("[789]\\d{9}");
//     if(re.test(control.value)){
//         return null;
//     }
//     else{
//         return {validPhoneNo:{value:control.value}};
//     }
// }
// }
