import { SearchMovie } from "./searchMovie";

export class Search {
    errorMessage!:string;
    expression!:string;
    results!: SearchMovie[];
    searchType!:string;
}