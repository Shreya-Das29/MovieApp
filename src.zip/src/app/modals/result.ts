import { Movie } from "./movie";

export class Result{
    items!: Movie[];
    errorMessage!:string;
}