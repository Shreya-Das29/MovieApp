export class Movie{
    id!: string;
    title!:string;
    image!:string;
    plot!:string;
    imDbRating!:string;
    genres!:string;
    directors!:string;
    stars!:string;
}